#!/bin/sh

BINDADDRESS="localhost" "$(dirname "$0")/server.sh"
